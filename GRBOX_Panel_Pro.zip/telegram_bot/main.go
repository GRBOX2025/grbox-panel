// full Telegram bot (Go) — create, my, block, синхронизация
