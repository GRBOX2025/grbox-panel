// full GRBOX backend (Go) — авторизация, API, PostgreSQL, подписки
