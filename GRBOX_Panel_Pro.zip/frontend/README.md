# GRBOX UI (React) — логин, админка, QR, блокировка
