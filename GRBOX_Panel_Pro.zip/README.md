# GRBOX Panel Pro
Полная версия панели: авторизация, Telegram, PostgreSQL, QR, подписки, админка
