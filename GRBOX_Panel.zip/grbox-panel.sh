#!/bin/bash
echo 'GRBOX Panel запущена...'
